
function Persona(nombre,apellido,dni) {

    this.Nombre=nombre;
    this.Apellido=apellido;
    this.Dni=dni;

}

module.exports=Persona;